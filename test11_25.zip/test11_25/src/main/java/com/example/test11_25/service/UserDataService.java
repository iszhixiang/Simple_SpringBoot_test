package com.example.test11_25.service;

import com.example.test11_25.pojo.UserData;
import java.util.List;

public interface UserDataService {
    List<UserData> findAllUsers();

    void deleteUserById(Long id);

    void saveUser(UserData userData);
}
