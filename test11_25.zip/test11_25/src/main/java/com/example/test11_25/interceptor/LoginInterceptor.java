package com.example.test11_25.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.HandlerInterceptor;

public class LoginInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 检查 session 是否有登录标志
        Object user = request.getSession().getAttribute("user");
        if (user == null) {
            // 如果未登录，重定向到登录页面
            response.sendRedirect("/user/login");
            return false; // 拦截请求
        }
        return true; // 放行
    }
}
