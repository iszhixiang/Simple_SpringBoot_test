package com.example.test11_25.service.impl;

import com.example.test11_25.pojo.User;
import com.example.test11_25.repository.UserRepository;
import com.example.test11_25.service.UserSerivice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserSerivice {

    @Autowired
    private UserRepository userRepository;


    @Override
    public User findByUsername(String username){
        return userRepository.findByUsername(username).orElse(null);
    }


    public void save(User user) {
        userRepository.save(user);
    }




    public void cancelById(Integer id) {
        userRepository.deleteById(Long.valueOf(id));
    }


    //


}
