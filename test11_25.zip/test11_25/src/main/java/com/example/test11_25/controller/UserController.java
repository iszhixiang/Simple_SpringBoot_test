package com.example.test11_25.controller;

import com.example.test11_25.pojo.User;
import com.example.test11_25.pojo.UserData;
import com.example.test11_25.service.UserDataService;
import com.example.test11_25.service.impl.UserServiceImpl;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserServiceImpl userService;//查询用户账户密码


    @Autowired
    private UserDataService userDataService;//查询用户资料




    //查询用户所有信息
    @GetMapping("/alluser")
    public String getAllUsers(Model model) {
        List<UserData> users = userDataService.findAllUsers();
        model.addAttribute("users", users);
        return "userList";
    }



    //用户登录页面
    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }


    //校验用户身份
    @PostMapping("/login")
    public String login(
            @RequestParam String username,
            @RequestParam String password,
            Model model,
            HttpServletRequest request) {
        User user = userService.findByUsername(username);
        if (user == null) {
            model.addAttribute("error", "用户名不存在");
            return "login";
        }
        if (!user.getPassword().equals(password)) {
            model.addAttribute("error", "密码错误");
            return "login";
        }

        // 登录成功，添加提示信息
        model.addAttribute("success", "登录成功");
        List<UserData> users = userDataService.findAllUsers();
        model.addAttribute("users", users);
        request.getSession().setAttribute("user", user);
        return "redirect:/user/alluser";
    }


    //注册页面
    @GetMapping("/enrool")
    public String enrool(){
        return "Enrool";
    }

    @PostMapping("/enrool")
    public String postenrool(
            @RequestParam String username,
            @RequestParam String password,
            RedirectAttributes redirectAttributes) {
        // 检查用户名是否已存在
        User existingUser = userService.findByUsername(username);
        if (existingUser != null) { // 用户已存在
            redirectAttributes.addFlashAttribute("error", "用户已经存在，请更换用户名");
            return "redirect:/user/enrool"; // 回到注册页面
        } else {
            // 创建新用户对象
            User newUser = new User();
            newUser.setUsername(username);
            newUser.setPassword(password); // 设置密码（明文）

            // 可选：其他字段设置默认值
            newUser.setEmail("");     // 默认值为空字符串

            // 保存新用户到数据库
            userService.save(newUser);

            // 提示成功消息
            redirectAttributes.addFlashAttribute("success", "注册成功，请登录");

            return "redirect:/user/login"; // 跳转到登录页面
        }





    }

    //退出登录
    @GetMapping("/logout")
    public String logout(HttpServletRequest request,RedirectAttributes redirectAttributes) {
        // 清除 Session 中的用户信息
        request.getSession().invalidate();
    redirectAttributes.addFlashAttribute("success","退出成功，请重新登录");
        // 返回登录页面
        return "redirect:/user/login";
    }


    //主页
    @GetMapping("/homepage")
    public String toHomePage(Model model, HttpSession session) {
        // 从 Session 中获取用户信息
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/user/login"; // 如果用户未登录，跳转到登录页面
        }

        model.addAttribute("user", user);
        return "homepage";
    }


    //删除用户信息
    @PostMapping("/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        userDataService.deleteUserById(id); // 调用 Service 删除用户数据
        return "redirect:/user/alluser"; // 删除后刷新页面，重定向到用户列表页面
    }

    //删除用户账号
    @PostMapping("/cancel/{id}")
    public String cancel(@PathVariable Long id,HttpServletRequest request,RedirectAttributes redirectAttributes){
        userService.cancelById(Math.toIntExact(id));
        request.getSession().invalidate();
        redirectAttributes.addFlashAttribute("success","注销成功，请重新登录");
        return "redirect:/user/login";
    }
    //添加资料
    @GetMapping("/add")
    public String addData(){
        return "addData";
    }

    @PostMapping("/addinformation")
    public String addinformation(UserData userData){
        userDataService.saveUser(userData);
        return "redirect:/user/alluser";
    }




}
