package com.example.test11_25;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test1125Application {

    public static void main(String[] args) {
        SpringApplication.run(Test1125Application.class, args);
    }

}
