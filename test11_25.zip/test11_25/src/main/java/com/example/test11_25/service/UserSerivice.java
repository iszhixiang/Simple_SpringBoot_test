package com.example.test11_25.service;

import com.example.test11_25.pojo.User;
import com.example.test11_25.pojo.UserData;

import java.util.List;

public interface UserSerivice {
    User findByUsername(String username);



}
