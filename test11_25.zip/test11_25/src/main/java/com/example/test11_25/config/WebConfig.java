package com.example.test11_25.config;

import com.example.test11_25.interceptor.LoginInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new LoginInterceptor())
                .addPathPatterns("/user/**") // 拦截所有 "/user/**" 的路径
                .excludePathPatterns(
                        "/user/login",   // 登录页面
                        "/user/enrool",  // 注册页面
                        "/user/enrool/**", // 注册操作
                        "/static/**",    // 静态资源（如 CSS、JS）
                        "/error"         // 错误页面
                );
    }
}
