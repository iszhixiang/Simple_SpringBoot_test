package com.example.test11_25.repository;

import com.example.test11_25.pojo.UserData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDataRepository extends JpaRepository<UserData, Integer> {
    // JpaRepository 提供基本的 CRUD 和分页查询功能，无需手动实现。
}
