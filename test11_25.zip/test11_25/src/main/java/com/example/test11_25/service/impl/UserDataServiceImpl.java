package com.example.test11_25.service.impl;

import com.example.test11_25.pojo.UserData;
import com.example.test11_25.repository.UserDataRepository;
import com.example.test11_25.service.UserDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserDataServiceImpl implements UserDataService {
    @Autowired
    private UserDataRepository userDataRepository;

    @Override
    public List<UserData> findAllUsers() {
        return userDataRepository.findAll();
    }

    public void deleteUserById(Long id) {
        userDataRepository.deleteById(Math.toIntExact(id));
    }
    public void saveUser(UserData userData) {
        userDataRepository.save(userData); // 保存用户到数据库
    }
}
