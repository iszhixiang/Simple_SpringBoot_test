package com.example.test11_25;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test1125ApplicationTests {

    @Test
    void contextLoads() {
    }

}
